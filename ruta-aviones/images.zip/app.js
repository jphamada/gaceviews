document.addEventListener('DOMContentLoaded', () => {
  
  // Elementos DOM Globales
  const infoWidget = document.getElementById('info-widget');
  const carouselTrack = document.getElementById('carousel-track');
  const slides = document.querySelectorAll('.carousel-slide');
  const prevBtn = document.getElementById('prev-btn');
  const nextBtn = document.getElementById('next-btn');
  const dotsContainer = document.getElementById('carousel-dots-container');
  const dots = document.querySelectorAll('.dot-btn');

  let currentSlide = 0;
  const totalSlides = slides.length;

  /* ==========================================
     1. LÓGICA DE NAVEGACIÓN DEL CARRUSEL
     ========================================== */
  function updateCarousel() {
    // Desplazar el track horizontalmente
    carouselTrack.style.transform = `translateX(-${currentSlide * 100}%)`;
    
    // Actualizar estados activos de los slides
    slides.forEach((slide, index) => {
      if (index === currentSlide) {
        slide.classList.add('active');
      } else {
        slide.classList.remove('active');
      }
    });

    // Actualizar puntos de navegación
    dots.forEach((dot, index) => {
      if (index === currentSlide) {
        dot.classList.add('active');
      } else {
        dot.classList.remove('active');
      }
    });

    // Habilitar/Deshabilitar flechas de control
    prevBtn.disabled = currentSlide === 0;
    nextBtn.disabled = currentSlide === totalSlides - 1;

    // Disparar eventos específicos según la diapositiva enfocada
    handleSlideTransitions(currentSlide);
  }

  function navigate(direction) {
    currentSlide += direction;
    if (currentSlide < 0) currentSlide = 0;
    if (currentSlide >= totalSlides) currentSlide = totalSlides - 1;
    updateCarousel();
  }

  // Event Listeners para botones de flechas
  prevBtn.addEventListener('click', () => navigate(-1));
  nextBtn.addEventListener('click', () => navigate(1));

  // Event Listeners para los puntos indicadores
  dotsContainer.addEventListener('click', (e) => {
    const targetDot = e.target.closest('.dot-btn');
    if (!targetDot) return;
    currentSlide = parseInt(targetDot.dataset.slideTarget, 10);
    updateCarousel();
  });

  // Soporte de Gestos Táctiles (Swipe) para Móviles
  let touchStartX = 0;
  let touchEndX = 0;
  const viewport = document.querySelector('.carousel-viewport');

  viewport.addEventListener('touchstart', (e) => {
    touchStartX = e.changedTouches[0].screenX;
  }, { passive: true });

  viewport.addEventListener('touchend', (e) => {
    touchEndX = e.changedTouches[0].screenX;
    handleSwipe();
  }, { passive: true });

  function handleSwipe() {
    const swipeThreshold = 55;
    if (touchEndX < touchStartX - swipeThreshold) {
      // Deslizar izquierda -> ir al siguiente
      if (currentSlide < totalSlides - 1) navigate(1);
    }
    if (touchEndX > touchStartX + swipeThreshold) {
      // Deslizar derecha -> ir al anterior
      if (currentSlide > 0) navigate(-1);
    }
  }

  // Gestor de transiciones de pantalla
  let countersAnimated = false;

  function handleSlideTransitions(slideIndex) {
    if (slideIndex === 1) {
      // Pantalla 2 activa: Disparar contadores una sola vez o re-animar
      if (!countersAnimated) {
        animateCounters();
        countersAnimated = true;
      }
    } else {
      // Resetear bandera al salir para que vuelvan a animarse si entra de nuevo
      countersAnimated = false;
    }
  }


  /* ==========================================
     2. PANTALLA 1 — INTERACTIVIDAD DEL MAPA
     ========================================== */
  const mapInfoBox = document.getElementById('map-info-box');
  const mapBtns = document.querySelectorAll('.map-btn');
  const mapNodes = document.querySelectorAll('.map-node');

  // Textos descriptivos por fase de ruta
  const phaseDescriptions = {
    "1": "<strong>Fase Aérea (Ingreso):</strong> Avionetas procedentes de Bolivia vuelan a baja altura para evadir radares. Descargan cocaína en campos del NOA mediante aterrizajes de 5 minutos en caminos rurales o 'bombardeos' (arrojar bultos en vuelo) sobre Salta y Chaco.",
    "2": "<strong>Fase Terrestre (Tránsito):</strong> Tras la descarga, la logística narco camufla los paquetes en camiones de granos o camionetas doble tracción. Utilizan la Ruta Nacional 34 como eje troncal y caminos de tierra rurales en Santiago del Estero y Tucumán.",
    "3": "<strong>Destino y Exportación:</strong> El flujo principal desciende hacia los puertos fluviales de la Hidrovía del Paraná (Rosario y Santa Fe), buscando buques comerciales con destino a Europa. Catamarca surge como una vía rápida alternativa hacia el Pacífico (Chile)."
  };

  // Textos detallados para nodos geográficos específicos
  const nodeDescriptions = {
    "bolivia": "<strong>Bolivia (Santa Cruz):</strong> Núcleo de acopio regional y pistas principales. Desde aquí reclutan pilotos jóvenes con aviones Cessna robados y matrículas duplicadas.",
    "salta": "<strong>Orán / Tartagal (Salta):</strong> Frontera caliente. Espacio aéreo saturado de vuelos irregulares que aterrizan en pistas boscosas desmontadas clandestinamente.",
    "anta": "<strong>Zona de Anta (Salta):</strong> Terreno agrícola llano, ideal para maniobras de 'bombardeo' de carga. Permite al avión arrojar la droga en bolsas y retornar a Bolivia sin aterrizar.",
    "chaco": "<strong>Chaco Salteño:</strong> Zonas remotas con escasa cobertura satelital. En esta selva seca se halló recientemente un Cessna 210 Centurion siniestrado del cual la carga fue retirada antes de llegar la policía.",
    "catamarca": "<strong>Catamarca:</strong> Corredor estratégico. Utilizada por los narcotraficantes para el tránsito ágil por pasos cordilleranos andinos hacia los puertos de Chile en el Océano Pacífico.",
    "santiago": "<strong>Santiago del Estero:</strong> Red de pistas de tierra escondidas en el monte. El eje troncal vial de la Ruta 34 canaliza aquí el transporte por tierra de cargamentos masivos.",
    "ports": "<strong>Puertos de la Hidrovía (Santa Fe / Rosario):</strong> Nodo neurálgico de exportación de la droga. La mercadería se oculta en contenedores de carga internacional para cruzar el Atlántico.",
    "pacific": "<strong>Vías del Pacífico:</strong> Terminales portuarias chilenas que sirven como trampolín de la cocaína hacia los mercados premium de alta demanda en Asia (Japón/China) y Oceanía."
  };

  // Configuración de Fase inicial en el widget
  infoWidget.setAttribute('data-active-phase', '1');
  mapInfoBox.innerHTML = phaseDescriptions["1"];

  // Click en botones de control de fase
  mapBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      // Cambiar botones activos
      mapBtns.forEach(b => b.classList.remove('active'));
      const clickedBtn = e.currentTarget;
      clickedBtn.classList.add('active');

      const phase = clickedBtn.dataset.phase;
      infoWidget.setAttribute('data-active-phase', phase);
      mapInfoBox.innerHTML = phaseDescriptions[phase];
    });
  });

  // Interacción al pasar el cursor o hacer click en nodos del mapa
  mapNodes.forEach(node => {
    node.addEventListener('mouseenter', () => {
      const nodeKey = node.dataset.node;
      if (nodeDescriptions[nodeKey]) {
        mapInfoBox.innerHTML = nodeDescriptions[nodeKey];
        mapInfoBox.style.borderColor = "var(--color-amber)";
      }
    });

    node.addEventListener('mouseleave', () => {
      // Retornar al texto de la fase activa seleccionada
      const activeBtn = document.querySelector('.map-btn.active');
      const currentPhase = activeBtn ? activeBtn.dataset.phase : '1';
      mapInfoBox.innerHTML = phaseDescriptions[currentPhase];
      mapInfoBox.style.borderColor = "var(--color-border)";
    });

    // Para dispositivos móviles (click fija el texto)
    node.addEventListener('click', (e) => {
      e.stopPropagation();
      const nodeKey = node.dataset.node;
      if (nodeDescriptions[nodeKey]) {
        mapInfoBox.innerHTML = nodeDescriptions[nodeKey];
        mapInfoBox.style.borderColor = "var(--color-amber)";
      }
    });
  });

  // Reset de caja del mapa al pulsar en vacío
  document.addEventListener('click', () => {
    const activeBtn = document.querySelector('.map-btn.active');
    if (activeBtn && currentSlide === 0) {
      const currentPhase = activeBtn.dataset.phase;
      mapInfoBox.innerHTML = phaseDescriptions[currentPhase];
      mapInfoBox.style.borderColor = "var(--color-border)";
    }
  });


  /* ==========================================
     3. PANTALLA 2 — NÚMEROS Y MATRIZ INTERACTIVA
     ========================================== */
  const gridContainer = document.getElementById('matrix-grid-container');
  const detailBox = document.getElementById('matrix-detail-box');

  const totalDots = 190;
  // Índices aleatorios distribuidos en la cuadrícula para los 5 casos reales
  const alertIndices = [18, 56, 92, 127, 161]; 

  const realCases = {
    "18": {
      title: "Decomiso Santa Fe I — 350 kg",
      desc: "<strong>Incautación de Inteligencia:</strong> En base a escuchas telefónicas previas se interceptó un cargamento masivo de cocaína oculto en un campo de la Hidrovía santafesina. La aeronave despegó del NOA y escapó, pero la carga terrestre fue capturada."
    },
    "56": {
      title: "Decomiso Santa Fe II — 350 kg",
      desc: "<strong>Redada en Pista Clandestina:</strong> Un operativo continuo allanó un galpón y una pista improvisada a la vera del río Paraná. Se detectó una avioneta descargando bultos a contrarreloj. Otros 350 kilos de droga de máxima pureza incautados."
    },
    "92": {
      title: "Cessna Estrellado en Chaco Salteño",
      desc: "<strong>Alerta Vecinal Tardía:</strong> Pobladores rurales denunciaron el estallido de un motor de avioneta. La Cessna 210 Centurion capotó en el monte seco. Sin embargo, las fuerzas de seguridad llegaron tarde: los narcos ya habían evacuado la cocaína."
    },
    "127": {
      title: "Bombardeo Detectado en Anta (Salta)",
      desc: "<strong>Operativo de Recuperación:</strong> Gendarmería Nacional divisó una aeronave realizando círculos a baja altura. Arrojó cuatro bultos con GPS incorporados en campos de soja. La avioneta retornó de inmediato a Bolivia; la droga fue secuestrada en tierra."
    },
    "161": {
      title: "Operativo Rosario de la Frontera",
      desc: "<strong>Maniobra Rápida Interceptada:</strong> Gendarmería detuvo una camioneta de apoyo que esperaba la descarga en una huella consolidada de ripio que operaba como helipuerto/pista improvisada. Se decomisó droga y bidones para reabastecimiento aéreo."
    }
  };

  // Poblar la matriz de 190 puntos
  function createMatrix() {
    gridContainer.innerHTML = '';
    for (let i = 0; i < totalDots; i++) {
      const dot = document.createElement('div');
      dot.className = 'matrix-dot';
      dot.dataset.index = i;

      // Verificar si es uno de los casos confirmados (alertas rojas)
      if (alertIndices.includes(i)) {
        dot.classList.add('dot-alert');
      }

      gridContainer.appendChild(dot);
    }
  }

  createMatrix();

  // Interacción de clicks e hilights en la cuadrícula
  gridContainer.addEventListener('click', (e) => {
    const clickedDot = e.target.closest('.matrix-dot');
    if (!clickedDot) return;

    const index = clickedDot.dataset.index;
    
    // Remover clase active de todos los puntos
    document.querySelectorAll('.matrix-dot').forEach(d => d.style.transform = '');

    if (alertIndices.includes(parseInt(index, 10))) {
      // Es un caso de éxito judicial (Punto Rojo)
      clickedDot.style.transform = 'scale(1.4)';
      const caseData = realCases[index];
      
      detailBox.innerHTML = `
        <div class="detail-content animate-fade">
          <div class="detail-title">🔴 ${caseData.title}</div>
          <p>${caseData.desc}</p>
        </div>
      `;
      detailBox.classList.add('active');
    } else {
      // Vuelo sospechoso ordinario
      clickedDot.style.transform = 'scale(1.2)';
      detailBox.innerHTML = `
        <div class="detail-placeholder animate-fade">
          <svg viewBox="0 0 24 24" fill="none" stroke="#8e9cae" stroke-width="1.5" style="width:14px;height:14px;">
            <circle cx="12" cy="12" r="10" />
            <line x1="12" y1="8" x2="12" y2="12" />
            <line x1="12" y1="16" x2="12.01" y2="16" />
          </svg>
          <p><strong>Vuelo Sospechoso no Interceptado:</strong> Tráfico aéreo catalogado como irregular. Escapa al control estatal debido a la escasez de radares activos en el NOA y la falta de helicópteros de persecución.</p>
        </div>
      `;
      detailBox.classList.remove('active');
    }
  });

  // Función para animar contadores numéricos de 0 a X
  function animateCounters() {
    const counterDetected = document.getElementById('count-detected');
    const counterConfirmed = document.getElementById('count-confirmed');

    if (!counterDetected || !counterConfirmed) return;

    animateSingleCounter(counterDetected, 190, 1500);
    animateSingleCounter(counterConfirmed, 5, 1200);
  }

  function animateSingleCounter(element, target, duration) {
    let startTimestamp = null;
    const step = (timestamp) => {
      if (!startTimestamp) startTimestamp = timestamp;
      const progress = Math.min((timestamp - startTimestamp) / duration, 1);
      element.innerText = Math.floor(progress * target);
      if (progress < 1) {
        window.requestAnimationFrame(step);
      } else {
        element.innerText = target; // Asegura número exacto final
      }
    };
    window.requestAnimationFrame(step);
  }


  /* ==========================================
     4. PANTALLA 3 — SIMULADOR Y SPECS DEL CESSNA
     ========================================== */
  const toggleDestNoa = document.getElementById('sim-dest-noa');
  const toggleDestPorts = document.getElementById('sim-dest-ports');
  const weightDisplay = document.getElementById('weight-display');
  const weightGaugeBar = document.getElementById('weight-gauge-bar');
  const cargoExtraPackages = document.getElementById('cargo-extra-packages');
  const cargoDrums = document.getElementById('cargo-drums');
  const simDetailsBox = document.getElementById('sim-details-box');
  const aircraftInfoOverlay = document.getElementById('aircraft-info-overlay');
  const hotspots = document.querySelectorAll('.hotspot-node');

  // Datos dinámicos del simulador de carga
  const simulatorConfigs = {
    "noa": {
      weight: "550 kg",
      percent: "100%",
      color: "var(--color-amber)",
      text: "<strong>Ruta Corta (Destino NOA):</strong> Vuelo directo desde Bolivia al sur de Salta, Tucumán o Santiago del Estero. Al ser menor trayecto, no requiere tanques ni bidones de combustible auxiliares. La cabina se optimiza para llevar la máxima carga útil de cocaína: <strong>550 kg (+150 kg extras libres de combustible)</strong>."
    },
    "ports": {
      weight: "400 kg",
      percent: "72.7%",
      color: "var(--color-red)",
      text: "<strong>Ruta Larga (Destino Central):</strong> Vuelo de largo alcance hasta campos de Santa Fe o Buenos Aires (1.600 km). Obliga a llevar bidones de combustible extra en cabina y un copiloto/asistente para reabastecer en vuelo de forma manual. Este peso muerto resta espacio y peso de carga neta de estupefaciente: <strong>Carga neta 400 kg</strong>."
    }
  };

  // Textos explicativos de los hotspots del fuselaje
  const hotspotTexts = {
    "gear": "<strong>Tren retráctil Centurion:</strong> A diferencia del Cessna 206, las ruedas se guardan en el fuselaje tras despegar. Reduce el rozamiento aerodinámico un 15%, aumentando velocidad y autonomía para escapar rápido de patrullas.",
    "range": "<strong>1.600 km de autonomía:</strong> El tanque alar maximizado permite al avión narco cruzar desde Bolivia a las provincias del litoral argentino, realizar bombardeos y volver a su pista de despegue inicial sin necesidad de aterrizar.",
    "runway": "<strong>Aterrizaje corto (STOL - 400m):</strong> Modificación extrema en las alas y flaps. Permite al Cessna 210 aterrizar y despegar a plena carga en caminos rurales precarios, huellas de tierra, ripio consolidado o rutas secundarias desiertas."
  };

  // Configuración de destino inicial
  infoWidget.setAttribute('data-active-dest', 'noa');
  simDetailsBox.innerHTML = simulatorConfigs["noa"].text;

  // Toggle Destino NOA (Corto Alcance)
  toggleDestNoa.addEventListener('click', () => {
    toggleDestNoa.classList.add('active');
    toggleDestPorts.classList.remove('active');
    infoWidget.setAttribute('data-active-dest', 'noa');

    // Cambios visuales dinámicos
    weightDisplay.innerText = simulatorConfigs["noa"].weight;
    weightDisplay.style.color = simulatorConfigs["noa"].color;
    weightGaugeBar.style.width = simulatorConfigs["noa"].percent;
    weightGaugeBar.style.backgroundColor = simulatorConfigs["noa"].color;
    simDetailsBox.innerHTML = simulatorConfigs["noa"].text;

    // Elementos del SVG Cessna
    if (cargoExtraPackages) cargoExtraPackages.classList.remove('hidden');
    if (cargoDrums) cargoDrums.classList.add('hidden');
  });

  // Toggle Destino Central/Puertos (Largo Alcance)
  toggleDestPorts.addEventListener('click', () => {
    toggleDestPorts.classList.add('active');
    toggleDestNoa.classList.remove('active');
    infoWidget.setAttribute('data-active-dest', 'ports');

    // Cambios visuales dinámicos
    weightDisplay.innerText = simulatorConfigs["ports"].weight;
    weightDisplay.style.color = simulatorConfigs["ports"].color;
    weightGaugeBar.style.width = simulatorConfigs["ports"].percent;
    weightGaugeBar.style.backgroundColor = simulatorConfigs["ports"].color;
    simDetailsBox.innerHTML = simulatorConfigs["ports"].text;

    // Elementos del SVG Cessna (Esconde extra, muestra bidones)
    if (cargoExtraPackages) cargoExtraPackages.classList.add('hidden');
    if (cargoDrums) cargoDrums.classList.remove('hidden');
  });

  // Interacción con los hotspots en el SVG de la avioneta
  hotspots.forEach(spot => {
    const triggerEvent = (e) => {
      e.stopPropagation();
      
      // Remover clase activo de otros hotspots
      hotspots.forEach(s => s.classList.remove('active'));
      spot.classList.add('active');

      const spotType = spot.dataset.spot;
      if (hotspotTexts[spotType]) {
        aircraftInfoOverlay.innerHTML = hotspotTexts[spotType];
        aircraftInfoOverlay.style.borderColor = "var(--color-cyan)";
      }
    };

    spot.addEventListener('mouseenter', triggerEvent);
    spot.addEventListener('click', triggerEvent);

    spot.addEventListener('mouseleave', () => {
      spot.classList.remove('active');
      aircraftInfoOverlay.innerHTML = `Pasa el cursor (o presiona) las zonas destacadas (<span class="pulse-spot-inline"></span>) de la aeronave para ver sus ventajas tácticas.`;
      aircraftInfoOverlay.style.borderColor = "var(--color-border)";
    });
  });

});
